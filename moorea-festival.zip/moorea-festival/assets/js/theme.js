;(function($) {
    "use strict"; 

    // sticky header js
    window.onscroll = function () {
        var header = document.querySelector("header");
        if (window.pageYOffset > 0) {
            header.classList.add("sticky");
        } else {
            header.classList.remove("sticky");
        }
    };
    
    // mobile menu js 
    $('.moorea-nav-open').click (function(){
        $(".navbar-closer, .moorea-overlay").click(function(){
            $(".header-section").removeClass("nav_activee");
        });
        $('.header-section').toggleClass("nav_activee");
    });
    if($('.header-menu li.dropdown ul').length){
        $('.header-menu li.dropdown').append('<div class="dropdown-btn"><span class="far fa-angle-down"></span></div>');
        $('.header-menu li.dropdown .dropdown-btn').on('click', function() {
            $(this).prev('ul').slideToggle(500);
        });
    };

    //data backgroud image js
    $("[data-background]").each(function() {
        $(this).css("background-image", "url(" + $(this).attr("data-background") + ")");
    });


    // partner section slider js
    $('.partner-carousel').owlCarousel({
        loop:true,
        margin:80,
        nav:true,
        dots:false,
        item: 3,
        navigation: true,
        navText: ["<i class='far fa-chevron-left'></i>","<i class='far fa-chevron-right'></i>"],
        responsive:{
            0:{
                items:1
            },
            768:{
                items:2
            },
            1000:{
                items:3
            },
            1040:{
                items:4
            }
        }
    })


  // countdown js 
    $('#countdown').countdown({
    date: '06/14/2024 23:59:59'
    }, function () {
    alert('Merry Christmas!');
    });


  
    //  Preloader js
    $(window).on('load', function() { 
    $('#loader').fadeOut();
    $('#preloader').delay(350).fadeOut('slow'); 
    })
    
  


//* Isotope js
    if ( $('.programmation-pages').length ){ 
        // Activate isotope in container
        $(".programmation-inner").imagesLoaded( function() {
            $(".programmation-inner").isotope({
                layoutMode: 'masonry',  
            }); 
        });  
        // Add isotope click function 
        $(".programmation-filter li").on('click',function(){
            $(".programmation-filter li").removeClass("active");
            $(this).addClass("active"); 
            var selector = $(this).attr("data-filter");
            $(".programmation-inner").isotope({
                filter: selector,
                animationOptions: {
                    duration: 450,
                    easing: "linear",
                    queue: false,
                }
            });
            return false;
        });  
    };

    //  animation js
    AOS.init({
    duration: 1200,
    })
 
    
})(jQuery);